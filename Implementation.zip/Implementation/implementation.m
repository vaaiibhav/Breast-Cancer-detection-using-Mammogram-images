run mammograms;
%run test;
run fuzzy;